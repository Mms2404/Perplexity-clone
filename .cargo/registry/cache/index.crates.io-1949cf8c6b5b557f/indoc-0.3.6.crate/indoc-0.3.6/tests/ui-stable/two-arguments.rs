use indoc::indoc;

fn main() {
    indoc!("
        a
        b
        c
        " 64);
}
