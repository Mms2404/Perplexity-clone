#![feature(proc_macro_hygiene)]

use indoc::indoc;

fn main() {
    indoc!();
}
