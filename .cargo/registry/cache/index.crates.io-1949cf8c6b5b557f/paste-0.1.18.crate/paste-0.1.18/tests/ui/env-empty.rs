paste::item! {
    fn [<env!()>]() {}
}

fn main() {}
