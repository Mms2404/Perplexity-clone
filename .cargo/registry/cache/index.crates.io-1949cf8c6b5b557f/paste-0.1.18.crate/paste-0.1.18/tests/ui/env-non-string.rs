paste::item! {
    fn [<env!(1.31)>]() {}
}

fn main() {}
