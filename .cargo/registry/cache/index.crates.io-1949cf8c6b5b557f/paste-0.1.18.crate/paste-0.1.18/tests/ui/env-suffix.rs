paste::item! {
    fn [<env!("VAR"suffix)>]() {}
}

fn main() {}
