paste::item! {
    fn [<env!("VAR" "VAR")>]() {}
}

fn main() {}
