paste::item! {
    fn [<0 f>]() {}
}

fn main() {}
