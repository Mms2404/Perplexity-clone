paste::item! {
    fn [<env! huh>]() {}
}

fn main() {}
