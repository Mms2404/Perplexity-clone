paste::item! {
    fn [<a env!("PASTE_UNKNOWN") b>]() {}
}

fn main() {}
