paste::item! {
    fn [<name:0>]() {}
}

fn main() {}
