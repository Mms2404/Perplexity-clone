paste::item! {
    fn [<:lower x>]() {}
}

fn main() {}
