paste::item! {
    fn [<a + b>]() {}
}

fn main() {}
