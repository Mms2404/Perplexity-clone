paste::item! {
    fn [<1e+100>]() {}
}

fn main() {}
