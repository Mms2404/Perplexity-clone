paste::item! {
    fn [<a:pillow>]() {}
}

fn main() {}
